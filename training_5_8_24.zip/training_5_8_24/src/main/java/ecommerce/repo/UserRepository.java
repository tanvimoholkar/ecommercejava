package ecommerce.repo;

import java.util.ArrayList;
import java.util.Optional;

import ecommerce.dto.Product;
import ecommerce.dto.User;
import ecommerce.exception.InvalidIDException;

public interface UserRepository {
	public User addUser(User user);
    public User getUserByUserId(String id) throws InvalidIDException;
    public Optional<ArrayList<User>> getUsers();
    public String removeUserByUserId(String id);
    public User updateUserByUserId(String id, User product);
    default void display() {
    	System.out.println("Hello from Interface");
    }
    
}
