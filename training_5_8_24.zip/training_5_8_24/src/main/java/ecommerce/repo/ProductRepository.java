package ecommerce.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import ecommerce.dto.Product;
import ecommerce.exception.DataNotFoundException;
import ecommerce.exception.InvalidIDException;

public interface ProductRepository {
    public Product addProduct(Product product);
    public Product getProductByProductId(String id) throws InvalidIDException;
    public List<Product> getProducts() throws DataNotFoundException;
    public List<Product> getAllProductsByCategory(String category) throws DataNotFoundException;
    public String removeProductByProductId(String id) throws InvalidIDException;
    public Product updateProductByProductId(String id, Product product);
    default void display() {
    	System.out.println("Hello from Interface");
    }
    
}