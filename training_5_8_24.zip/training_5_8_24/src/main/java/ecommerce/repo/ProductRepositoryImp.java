package ecommerce.repo;

import java.util.HashSet;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import ecommerce.repo.ProductRepository;

import ecommerce.dto.Product;
import ecommerce.exception.DataNotFoundException;
import ecommerce.exception.InvalidIDException;

public class ProductRepositoryImp implements ProductRepository {
private ProductRepositoryImp() {
	// TODO Auto-generated constructor stub
}
private static ProductRepository productRepository;
//private Product[] products = new Product[10];
private HashSet<Product> products=new HashSet<>();
public static ProductRepository getInstance() {
	if(productRepository==null)
		productRepository= new ProductRepositoryImp();
	
	return productRepository;
}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		
		boolean res= products.add(product);
	    return product;
//		return null;
	}

	@Override
	public Product getProductByProductId(String id) throws InvalidIDException {
		// TODO Auto-generated method stub
		return products.stream().
				filter(e->e.getProductId().
						equals(id)).findFirst().orElseThrow(()->new InvalidIDException(""));
	}
//    static Product p;
	
	@Override
	public List<Product> getProducts() throws DataNotFoundException {
		// TODO Auto-generated method stub
//		static Product p;
		return Optional.ofNullable(products.stream().collect(Collectors.toList())).filter(l->!l.isEmpty()).orElseThrow(()->new DataNotFoundException("hewlo"));
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) throws DataNotFoundException {
		// TODO Auto-generated method stub
		return Optional.ofNullable(products.stream().
				filter(e->e.getCategoryName().equals(category)).
				collect(Collectors.toList())).orElseThrow(()->new DataNotFoundException("not found"));
		
//		Product[] temp= new Product[10];
//		int indx=0;
//		for(Product product:products) {
//			if(product!=null && product.getCategoryName().equals(category)) {
//				if(indx==temp.length) {
//					temp=Arrays.copyOf(temp, 2*temp.length);
//				}
//				temp[indx++]=product;
//			}
//		}
//		return Optional.ofNullable(temp);
	}

	@Override
	public String removeProductByProductId(String id) throws InvalidIDException {
		// TODO Auto-generated method stub
		Product product= this.getProductByProductId(id);
		boolean res = products.remove(product);

		return res?"Success":"Fail";
	}

	@Override
	public Product updateProductByProductId(String id, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
