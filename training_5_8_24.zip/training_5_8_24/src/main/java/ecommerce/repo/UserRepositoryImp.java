package ecommerce.repo;

import java.util.ArrayList;
import java.util.Optional;

import ecommerce.dto.User;
import ecommerce.exception.InvalidIDException;

public class UserRepositoryImp implements UserRepository {
  private static UserRepository userRepository;
  private ArrayList<User> users= new ArrayList<>();
  public static UserRepository getInstance() {
	  if(userRepository==null)
		  userRepository=new UserRepositoryImp();
	  return userRepository;
  }
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		 users.add(user);
		return user;
	}

	@Override
	public User getUserByUserId(String id) throws InvalidIDException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<ArrayList<User>> getUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String removeUserByUserId(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User updateUserByUserId(String id, User product) {
		// TODO Auto-generated method stub
		return null;
	}

}
