package ecommerce;

import java.util.List;
import java.util.Optional;

import ecommerce.dto.Product;
import ecommerce.exception.DataNotFoundException;
import ecommerce.exception.InvalidIDException;
import ecommerce.exception.InvalidPriceException;
import ecommerce.service.ProductService;
import ecommerce.service.ProductServiceImp;

public class Main {
   public static int test() {
	   int a=0;
	   int b[]=new int[10];
	   
	   try {
		   a=10/0;
		   b[10]=5;
		   System.out.println("int try");
		   
		   return a;
	   }
	   catch(ArrayIndexOutOfBoundsException e) {
		   System.out.println("array index out");
	   }
	   catch(ArithmeticException e) {
		   System.out.println("catch");
	   }
	   finally {
		   System.out.println("finally");
		   return a;
	   }
	   
   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int aa=test();
		System.out.println(aa);
      ProductService productService= ProductServiceImp.getInstance();
    //  for(int i=0;i<10;i++)
     try {
    	 productService.addProduct(new Product("0","car","carr",450)); 
    	 System.out.println("fff");
     }
     catch(InvalidIDException e) {
    	 e.printStackTrace();
    	 System.out.println(e.getMessage());
     }
     catch(InvalidPriceException e) {
    	 e.printStackTrace();
    	 System.out.println(e.getMessage().toString());
     }
      Product p= new Product();
//     Optional<Product> p1=productService.getProductByProductId("5050");
//     if(p1.isPresent()) {
//    	 Product result= p1.get();
//    	 System.out.println(result.getProductName());
//     }
      try {
    	  List<Product> ppp =productService.getAllProductsByCategory("cc");
    	  System.out.println(ppp);
      }
      catch(DataNotFoundException e) {
    	  System.out.println(e);
      }
     int a=10;
     try {
    	 a=10/0;
    	 System.out.println("");
     }
     catch(Exception e) {
    	 
     }
     finally {
    	 
     }
       
}
	
}
