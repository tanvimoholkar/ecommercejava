package ecommerce.service;

import java.util.ArrayList;
import java.util.Optional;

import ecommerce.dto.User;
import ecommerce.exception.InvalidIDException;
import ecommerce.repo.UserRepository;
import ecommerce.repo.UserRepositoryImp;

public class UserServiceImpl implements UserService{
 private UserRepository userRepository = UserRepositoryImp.getInstance();
 private static UserService userService;
 private UserServiceImpl() {
	 
 }
 public static UserService getInstance() {
		if(userService==null)
			userService=new UserServiceImpl();
		return userService;
	}
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.addUser(user);
	}

	@Override
	public User getUserByUserId(String id) throws InvalidIDException {
		// TODO Auto-generated method stub
		return userRepository.getUserByUserId(id);
	}

	@Override
	public Optional<ArrayList<User>> getUsers() {
		// TODO Auto-generated method stub
		return userRepository.getUsers();
	}

	@Override
	public String removeUserByUserId(String id) {
		// TODO Auto-generated method stub
		return userRepository.removeUserByUserId(id);
	}

	@Override
	public User updateUserByUserId(String id, User product) {
		// TODO Auto-generated method stub
		return userRepository.updateUserByUserId(id, product);
	}

}
