package ecommerce.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import ecommerce.dto.Product;
import ecommerce.exception.DataNotFoundException;
import ecommerce.exception.InvalidIDException;
import ecommerce.repo.ProductRepository;
import ecommerce.repo.ProductRepositoryImp;

public class ProductServiceImp implements ProductService {

	private ProductRepository productRepository = ProductRepositoryImp.getInstance();
	private static ProductService productService; 
	private ProductServiceImp() {
		
	}
	public static ProductService getInstance() {
		if(productService==null)
			productService=new ProductServiceImp();
		return productService;
	}
	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productRepository.addProduct(product);
	}

	@Override
	public Product getProductByProductId(String id) throws InvalidIDException {
		// TODO Auto-generated method stub
		return productRepository.getProductByProductId(id);
	}

	@Override
	public List<Product> getProducts() throws DataNotFoundException {
		// TODO Auto-generated method stub
		return (List<Product>) productRepository.getProducts();
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) throws DataNotFoundException {
		// TODO Auto-generated method stub
//		return userRepository.g
		return (List<Product>) productRepository.getAllProductsByCategory(category);
	}

	@Override
	public String removeProductByProductId(String id) throws InvalidIDException {
		// TODO Auto-generated method stub
		return productRepository.removeProductByProductId(id);
	}

	@Override
	public Product updateProductByProductId(String id, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

}
