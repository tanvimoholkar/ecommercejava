package ecommerce.service;

import java.util.ArrayList;
import java.util.Optional;

import ecommerce.dto.User;
import ecommerce.exception.InvalidIDException;

public interface UserService {
	public User addUser(User user);
    public User getUserByUserId(String id) throws InvalidIDException;
    public Optional<ArrayList<User>> getUsers();
    public String removeUserByUserId(String id);
    public User updateUserByUserId(String id, User product);
}
