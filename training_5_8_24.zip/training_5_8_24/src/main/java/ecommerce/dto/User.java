package ecommerce.dto;

public class User {
  private String id, userid, firstname, lastname, address, contact;

public String getId() {
	return id;
}

public User() {
	super();
}

public User(String id, String userid, String firstname, String lastname, String address, String contact) {
	super();
	this.id = id;
	this.userid = userid;
	this.firstname = firstname;
	this.lastname = lastname;
	this.address = address;
	this.contact = contact;
}

public void setId(String id) {
	this.id = id;
}

public String getUserid() {
	return userid;
}

public void setUserid(String userid) {
	this.userid = userid;
}

public String getFirstname() {
	return firstname;
}

public void setFirstname(String firstname) {
	this.firstname = firstname;
}

public String getLastname() {
	return lastname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getContact() {
	return contact;
}

public void setContact(String contact) {
	this.contact = contact;
}
  
}
