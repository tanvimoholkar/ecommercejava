package ecommerce.dto;

import ecommerce.exception.InvalidIDException;
import ecommerce.exception.InvalidPriceException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.ToString.Exclude;

@Getter
@ToString
//@EqualsAndHashCode

//@Data
//@NoArgsConstructor
public class Product {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((categoryName == null) ? 0 : categoryName.hashCode());
		result = prime * result + Float.floatToIntBits(price);
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (categoryName == null) {
			if (other.categoryName != null)
				return false;
		} else if (!categoryName.equals(other.categoryName))
			return false;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		return true;
	}

	private String productId;
	private String productName;
	private String categoryName;
	private float price;
	public Product() {
		
	}
    public void setProductId(String productId) throws InvalidIDException {
    	if(productId==null || productId.equals("") || productId.length()<3)
    		throw new InvalidIDException("invalid id");
    	this.productId=productId;
    }
    public void setPrice(float price) throws InvalidPriceException {
    	if(price==0)
    		throw new InvalidPriceException("invalid price");
    	this.price=price;
    }
  
	public Product(String productId, String productName, String categoryName, float price) throws InvalidIDException, InvalidPriceException {
		this.setProductId(productId);
		this.productName = productName;
		this.categoryName = categoryName;
		this.setPrice(price);
	}
}
