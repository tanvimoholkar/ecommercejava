package ecommerce.exception;

public class InvalidIDException extends Exception{
	public InvalidIDException(String msg) {
		super(msg);
	}
	@Override
	public String toString() {
		return "Hellow";
          		
	}

}
